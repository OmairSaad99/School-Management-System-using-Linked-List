
#include "stdlib.h"
#include "string.h"
#include "File.h"
void MAIN_MENU() /*Main Menu*/
{
    StudentNode ptrs ;
    LinkedList ptrl ;


    int Exit_flag = 0 ; /*Flag To Exit From System*/

    int Option, Position, numberOfStudents,ID ;
    printf("                      ************WELCOME TO OUR SCHOOL MANAGMENT SYSTEM***************                      ") ;

    CreateList(&ptrl);

    while (Exit_flag != 1)
    {
        printf("\n\nThese are the options for the operations to be executed");
        printf("\n1 - Create New Student Account");
        printf("\n2 - Update a Particular Student Account");
        printf("\n3 - Delete a Particular Student Account");
        printf("\n4 - List Student Information");
        printf("\n5 - Rank Student According To Computer Science Score");
        printf("\n6 - Update Score For all Students");
        printf("\n7 - EXIT");
        printf("\nEnter Option of Your Operation : ") ;
        scanf("%d", &Option) ;
        switch(Option)
        {
        case 1 :
            if (!isEmpty(&ptrl))
            {
                printf("\nEnter position where you want enter Student : ") ;
                scanf("%d", &Position);
                while(Position < 0 || Position > getSize(&ptrl)) /*Checking if The Entered Position in range of The List*/
                {
                    printf("Position Out Of Range ... ! , Enter the Correct Position : ") ;
                    scanf("%d", &Position);
                }
                printf("\nEnter Data of Student %d\n\n",(getSize(&ptrl) + 1));
                NEW_STUDENT(Position, &ptrl);
            }
            else
            {
                printf("\nEnter the number of students you want to create a new account for : ") ;
                scanf("%d", &numberOfStudents);

                for (int i=0 ; i<numberOfStudents ; i++)
                {
                    printf("\nEnter Data of Student %d\n\n",(getSize(&ptrl) + 1));
                    NEW_STUDENT(i, &ptrl);
                }
            }
            printf("\nOperation Done Successfully ... !") ;
            break ;
        case 2 :
            if (!isEmpty(&ptrl))
            {
                printf("\nEnter ID of Student that you want to update its Account : ") ;
                scanf("%d", &ID);
                STUDENT_EDIT(&ptrl, ID);
            }
            else
            {
                printf("\nStudent Account List is Empty ...! YOU MUST CREATE STUDENT ACCOUNTS FIRST") ;
            }
            break ;
        case 3 :
            if (!isEmpty(&ptrl))
            {
                printf("\nEnter ID of Student that you want to delete its Account : ") ;
                scanf("%d", &ID);
                DELETE_STUDENT(&ptrl, ID);
            }
            else
            {
                printf("\nStudent Account List is Empty ...! YOU MUST CREATE STUDENT ACCOUNTS FIRST") ;
            }
            break ;
        case 4 :
            if (!isEmpty(&ptrl))
            {
                printf("\nList of All Students \n") ;
                STUDENT_LIST(&ptrl);
            }
            else
            {
                printf("\nStudent Account List is Empty ...! YOU MUST CREATE STUDENT ACCOUNTS FIRST") ;
            }
            break ;
        case 5 :
            if (!isEmpty(&ptrl))
            {
                printf("\nNow, We Rank Students By CS Grade.\n");
                RANK_STUDENT(&ptrl);
            }
            else
            {
                printf("\nStudent Account List is Empty ...! YOU MUST CREATE STUDENT ACCOUNTS FIRST") ;
            }
            break ;
        case 6 :
            if (!isEmpty(&ptrl))
            {
                printf("\nNow, You Update All Students' Scores.\n\n") ;
                STUDENT_SCORE(&ptrl);
                printf("\nStudents' Scores Updated Successfully ...!");
            }
            else
            {
                printf("\nStudent Account List is Empty ...! YOU MUST CREATE STUDENT ACCOUNTS FIRST") ;
            }
            break ;
        case 7 :
            Exit_flag = 1 ;
            break ;
        default :
            printf("\nInvalid Option ... ! Please Enter The Correct option From 1 to 7");
            break ;
        }

        if (Exit_flag == 1)
        {
            printf("\nTHANK YOU FOR USUING OUR SYSTEM\n") ;
            break ;
        }
    }
}

void CreateList (LinkedList *Ptrl)   /*Create Empty List with Size 0*/
{
    Ptrl->LengthOfList = 0 ;
    Ptrl->first = Ptrl->last = NULL ;
}


void Insert_Student_at_First_Pos(StudentNode *ptrs, LinkedList *Ptrl)/*Insert Student at first Position of List*/
{
    if (Ptrl->LengthOfList == 0)
    {
        Ptrl->first = Ptrl->last = ptrs ;
        ptrs->NextStudent = NULL ;

    }
    else
    {
        ptrs->NextStudent = Ptrl->first;
        Ptrl->first= ptrs ;
    }

}

void Insert_Student_at_Last_Pos (StudentNode *ptrs, LinkedList *Ptrl)/*Insert Student at Last Position of List*/
{
    if (Ptrl->LengthOfList == 0)
    {
        Ptrl->first = Ptrl->last = ptrs ;
        ptrs->NextStudent = NULL;
    }
    else
    {
        Ptrl->last->NextStudent = ptrs ;
        ptrs->NextStudent = NULL;
        Ptrl->last =ptrs ;
    }

}

void NEW_STUDENT (int Position, LinkedList *Ptrl) /*Insert Student at Specific Position*/
{
    StudentNode *ptrs = (StudentNode*)malloc(sizeof(StudentNode)) ; /*Dynamic Memory Allocation To Create New Student Node*/
    static int ID = 999;

    printf("Enter Name Of Student : ") ;
    scanf(" %[^\n]%*c", &ptrs->Name);

    printf("Enter Student Date Of Birth : ") ;
    scanf("%[^\n]%*c", &ptrs->Birthday);

    printf("Enter Student Address : ") ;
    scanf(" ");
    gets(ptrs->Address);

    printf("Enter Student Phone Number : ") ;
    scanf("%s", &ptrs->phoneNumber);

    ptrs->Computer_Science_Score = 0 ;

    if (Position == 0) /*if the Entered Position is 0 Insert Student at the first Position of List*/
    {
        Insert_Student_at_First_Pos(ptrs, Ptrl);
    }
    else if (Position == Ptrl->LengthOfList) /*if the Entered Position is 0 Insert Student at the Last Position of List*/
    {
        Insert_Student_at_Last_Pos(ptrs, Ptrl);
    }
    else /*if the Entered Position is between 0 and length of List Insert Student at the Choosen Position Position of List*/
    {
        StudentNode *temp ;
        temp = Ptrl->first ;
        for (int i=1 ; i<Position ; i++) /*Loop till the Determined position - 1*/
        {
            temp = temp->NextStudent ;
        }
        ptrs->NextStudent = temp->NextStudent ;
        temp->NextStudent = ptrs ;
    }

    Ptrl->LengthOfList ++ ; /*Increment Length Of List*/
    ID ++ ;
    ptrs->ID = ID ;
}

void DELETE_STUDENT (LinkedList *Ptrl, int ID) /*Delete Particular Student Account using ID*/
{
    StudentNode *ptrs ;
    if (Ptrl->first->ID == ID) /*Check if Id of student is at the First Node*/
    {
        ptrs = Ptrl->first ;
        Ptrl->first = Ptrl->first->NextStudent ;
        free(ptrs);/*Delete student that have the specific ID*/
        Ptrl->LengthOfList -- ;
        printf("\nStudent Deleted Successfully ... !") ;
    }
    else
    {
        ptrs = Ptrl->first->NextStudent ;
        StudentNode* Previous = Ptrl->first;
        while (ptrs != NULL && ptrs->ID != ID)
        {
            Previous = ptrs ;
            ptrs = ptrs->NextStudent ;
        }
        if (ptrs == NULL)
        {
            printf("\nID Not Found") ;
        }
        else
        {
            Previous->NextStudent = ptrs->NextStudent ;
            free(ptrs) ;
            Ptrl->LengthOfList -- ;
            printf("\nStudent Deleted Successfully ... !") ;
        }

    }

}


void STUDENT_LIST(LinkedList *Ptrl) /*View Student Information*/
{
    StudentNode *ptrs = Ptrl->first;

    StudentNode* ptrsNext = (StudentNode*)malloc(sizeof(StudentNode));
    StudentNode* temp = (StudentNode*)malloc(sizeof(StudentNode));
    for (int i=0 ; i<Ptrl->LengthOfList ; i++)
    {
        ptrs = Ptrl->first;
        ptrsNext = ptrs->NextStudent;
        for (int j=0 ; j<Ptrl->LengthOfList - i - 1 ; j++)
        {
            char c = strcasecmp(ptrs->Name, ptrsNext->Name); /*Fun To Compare Strings and Ignore Capital and Small Charactes*/

            if (c > 0)
            {
                strcpy(temp->Name, ptrs->Name);
                strcpy(ptrs->Name, ptrsNext->Name);
                strcpy(ptrsNext->Name, temp->Name);

                strcpy(temp->Birthday, ptrs->Birthday);
                strcpy(ptrs->Birthday, ptrsNext->Birthday);
                strcpy(ptrsNext->Birthday, temp->Birthday);

                strcpy(temp->Address, ptrs->Address);
                strcpy(ptrs->Address, ptrsNext->Address);
                strcpy(ptrsNext->Address, temp->Address);

                strcpy(temp->phoneNumber, ptrs->phoneNumber);
                strcpy(ptrs->phoneNumber, ptrsNext->phoneNumber);
                strcpy(ptrsNext->phoneNumber, temp->phoneNumber);

                temp->ID = ptrs->ID;
                ptrs->ID = ptrsNext->ID ;
                ptrsNext->ID = temp->ID ;

                temp->Computer_Science_Score = ptrs->Computer_Science_Score;
                ptrs->Computer_Science_Score = ptrsNext->Computer_Science_Score ;
                ptrsNext->Computer_Science_Score = temp->Computer_Science_Score ;
            }
            ptrs = ptrs->NextStudent;
            ptrsNext = ptrs->NextStudent;
        }
    }
    free(temp);
    temp = NULL ;

    ptrs = Ptrl->first ;
    while (ptrs != NULL)
    {
        printf("\n");
        printf("%s  ",ptrs->Name);
        printf("%s  ",ptrs->Birthday);
        printf("%d  ",ptrs->ID);
        printf("%s  ",ptrs->Address);
        printf("%s  ",ptrs->phoneNumber);

        ptrs = ptrs->NextStudent;
    }
}

void STUDENT_EDIT (LinkedList *Ptrl, int ID) /*Update Particular student Account*/
{
    int Exit_flag = 0; /*Flag To exit From loop*/
    int Edit_flag = 0 ;/*flag that Detected ID is Found*/
    int Choice;
    StudentNode *ptrs = Ptrl->first;

    while (ptrs != NULL)
    {
        if (ptrs->ID == ID) /*Check if Id of student is at the First Node*/
        {
            Edit_flag = 1 ;
            while (Exit_flag != 1)
            {
                printf("\nPress (1) to Update Name Of Student Whose Id : %d", ptrs->ID) ;
                printf("\nPress (2) to Update Date Of Birth Of Student Whose Id : %d", ptrs->ID) ;
                printf("\nPress (3) to Update Address Of Student Whose Id : %d", ptrs->ID) ;
                printf("\nPress (4) to Update Phone Number Of Student Whose Id : %d", ptrs->ID) ;
                printf("\nPress (5) To Exit\n") ;
                printf("\nEnter Option of Your Operation : ") ;
                scanf("%d", &Choice) ;

                if (Choice == 1)
                {
                    printf("\nEnter new Name : ") ;
                    scanf(" ");
                    scanf("%[^\n]%*c", &ptrs->Name);
                }
                else if (Choice == 2)
                {
                    printf("Enter new Date of Birth : ") ;
                    scanf(" ");
                    scanf("%[^\n]%*c", &ptrs->Birthday);
                }
                else if (Choice == 3)
                {
                    printf("Enter new Address : " ) ;
                    scanf(" ");
                    gets(&ptrs->Address);
                }
                else if (Choice == 4)
                {
                    printf("Enter new Phone Number : ") ;
                    scanf("%s", &ptrs->phoneNumber);
                }
                else if (Choice == 5)
                {
                    printf("Operation Done Successfully ... !") ;
                    Exit_flag = 1 ;
                }
                else
                {
                    printf("\nInvalid Option ... !\n") ;
                }
            }
        }
        if (Exit_flag == 1) /*Exit From The First While loop*/
            break ;
        else
            ptrs = ptrs->NextStudent ;
    }

    if (Edit_flag == 0)
    {
        printf("\nID Not Found") ;
    }

}

void RANK_STUDENT(LinkedList *Ptrl)/*Rank Students According to CS Score*/
{
    StudentNode *ptrs;
    StudentNode* ptrsNext = (StudentNode*)malloc(sizeof(StudentNode));
    StudentNode* temp = (StudentNode*)malloc(sizeof(StudentNode));
    for (int i=0 ; i<Ptrl->LengthOfList ; i++)
    {
        ptrs = Ptrl->first;
        ptrsNext = ptrs->NextStudent;
        for (int j=0 ; j<Ptrl->LengthOfList - i - 1 ; j++)
        {
            if (ptrs->Computer_Science_Score < ptrsNext->Computer_Science_Score)
            {
                strcpy(temp->Name, ptrs->Name);
                strcpy(ptrs->Name, ptrsNext->Name);
                strcpy(ptrsNext->Name, temp->Name);

                strcpy(temp->Birthday, ptrs->Birthday);
                strcpy(ptrs->Birthday, ptrsNext->Birthday);
                strcpy(ptrsNext->Birthday, temp->Birthday);

                strcpy(temp->Address, ptrs->Address);
                strcpy(ptrs->Address, ptrsNext->Address);
                strcpy(ptrsNext->Address, temp->Address);

                strcpy(temp->phoneNumber, ptrs->phoneNumber);
                strcpy(ptrs->phoneNumber, ptrsNext->phoneNumber);
                strcpy(ptrsNext->phoneNumber, temp->phoneNumber);

                temp->ID = ptrs->ID;
                ptrs->ID = ptrsNext->ID ;
                ptrsNext->ID = temp->ID ;

                temp->Computer_Science_Score = ptrs->Computer_Science_Score ;
                ptrs->Computer_Science_Score = ptrsNext->Computer_Science_Score ;
                ptrsNext->Computer_Science_Score = temp->Computer_Science_Score ;

            }
            ptrs = ptrs->NextStudent;
            ptrsNext = ptrs->NextStudent;
        }
    }
    free(temp);
    temp = NULL ;


    ptrs = Ptrl->first ;
    while (ptrs != NULL)
    {
        printf("\n%s  ",ptrs->Name);
        printf("%s  ",ptrs->Birthday);
        printf("%d  ",ptrs->ID);
        printf("%s  ",ptrs->Address);
        printf("%s  ",ptrs->phoneNumber);
        printf("%d  ",ptrs->Computer_Science_Score);

        ptrs = ptrs->NextStudent;
    }
}


void STUDENT_SCORE(LinkedList *ptrl)/*Update Score For all Students*/
{
    int Choice ;
    StudentNode *ptrs = ptrl->first ;

    while (ptrs != NULL)
    {
        printf("Press (1) to Update Score For %s , (0) OtherWise : ", ptrs->Name) ;
        scanf("%d", &Choice) ;
        switch(Choice)
        {
        case 1 :
            printf("Enter New CS Score Of %s : ",ptrs->Name);
            scanf("%d", &ptrs->Computer_Science_Score) ;
            while (ptrs->Computer_Science_Score>100 || ptrs->Computer_Science_Score < 0)
            {
                printf("Score Invalid ... ! , Enter CS Score Of %s Again ..! : ", ptrs->Name) ;
                scanf("%d", &ptrs->Computer_Science_Score) ;
            }
            ptrs = ptrs->NextStudent ;
            break ;
        case 0 :
            ptrs = ptrs->NextStudent ;
            break ;
        default :
            printf("\nChoice Invalid ... ! , Enter Choice Again ..!\n\n") ;
            break;
        }
    }
}

int getSize(LinkedList *Ptrl) /*Return Length Of List*/
{
    return Ptrl->LengthOfList ;
}

int isEmpty(LinkedList *Ptrl) /*Check is List is Empty*/
{
    return Ptrl->LengthOfList == 0 ;
}
