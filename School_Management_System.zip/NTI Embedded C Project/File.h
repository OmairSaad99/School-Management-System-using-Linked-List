#ifndef FILE_H_INCLUDED
#define FILE_H_INCLUDED
#include "stdio.h"
#include "ctype.h"
#include "string.h"


#define MaxSizename 50
#define MaxSizeAddress 100
#define MaxSizePhoneNumber 15
#define MaxSizeBirthday 11

typedef struct
{
    char Name[MaxSizename] ;
    char Birthday[MaxSizeBirthday] ;
    char Address[MaxSizeAddress] ;
    char phoneNumber[MaxSizePhoneNumber];
    int ID ;
    int Computer_Science_Score ;
    struct StudentNode *NextStudent ;
} StudentNode;

typedef struct
{
    StudentNode* first ;
    StudentNode* last ;
    int LengthOfList ;
} LinkedList;



void MAIN_MENU() ; /*Main Menu*/

void CreateList (LinkedList *Ptrl) ; /*Create Empty List with Size 0*/

void Insert_Student_at_First_Pos (StudentNode *ptrs, LinkedList *Ptrl ) ; /*Insert Student at first Position of List*/

void Insert_Student_at_Last_Pos (StudentNode *ptrs, LinkedList *Ptrl ) ; /*Insert Student at Last Position of List*/

void NEW_STUDENT (int Position, LinkedList *Ptrl) ; /*Insert Student at Specific Position*/

void DELETE_STUDENT (LinkedList *Ptrl, int ID) ; /*Delete Particular Student Account using ID*/

void STUDENT_LIST(LinkedList *Ptrl) ; /*View Student Information*/

void STUDENT_EDIT (LinkedList *Ptrl, int ID) ; /*Update Particular student Account*/

void RANK_STUDENT(LinkedList *ptrl) ; /*Rank Students According to CS Score*/

void STUDENT_SCORE(LinkedList *ptrl); /*Update Score For all Students*/

int getSize(LinkedList *Ptrl) ; /*Return Length Of List*/

int isEmpty(LinkedList *Ptrl) ; /*Return Length Of List*/


#endif // FILE_H_INCLUDED
